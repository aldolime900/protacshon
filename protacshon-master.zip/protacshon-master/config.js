module.exports = {
    TOKEN: 'NzIxMTQ1NjM4Nzg3NjEyNzQy.XuuEwA.pqIVtL5AkavbcjYSz2rO2Z6w2Qk',//هون التوكن     
    YT_API_KEY: 'AIzaSyDeoIH0u1e72AtfpwSKKOSy3IPp2UHzqi4 ', 
    prefix: '$',//هون برفكس البوت 
    devs: ['604301201651138561']//هون ايديك 
}
